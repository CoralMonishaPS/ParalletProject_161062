package com.cg.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bank.exception.AccountException;
import com.cg.bank.exception.AmountException;
import com.cg.bank.exception.NameException;
import com.cg.bank.exception.PhoneNumberException;
import com.cg.bank.service.AccountServiceImpl;

public class BankTest {
	
	@Test
	public void ValidateNameTrue() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validateName("Gulshan"));
	}
	@Test 
	public void ValidateName() throws NameException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validateName("Keerthana96"));
		assertEquals(false, as.validateName("Keerthana"));
		assertEquals(false, as.validateName("Keerthana@#"));
		assertEquals(false, as.validateName("090896"));
	}
	
	@Test
	public void ValidatePhonNumberTrue() throws PhoneNoException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(true, as.validatePhoneNo("9494513087"));
	}
	
	@Test
	public void ValidatePhoneNumber() throws PhoneNumberException{
		AccountServiceImpl as = new AccountServiceImpl();
		assertEquals(false, as.validatePhoneNumber("98632"));
		assertEquals(false, as.validatePhoneNumber("4634862470"));
		assertEquals(false, as.validatePhoneNumber("6317"));
		assertEquals(false, as.validatePhoneNumber("testing"));
		assertEquals(false, as.validatePhoneNumber("@#*%"));
	}
	
	@Test
	public void ValidateAmountTrue() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("150"));
	}
	
	@Test 
	public void ValidateAmount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-100"));
	}
	
	@Test
	public void ValidateAccountTrue() throws AccountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(true, bs.validateAmount("12345"));
		
	}
	@Test 
	public void ValidateAccount() throws AmountException{
		AccountServiceImpl bs = new AccountServiceImpl();
		assertEquals(false, bs.validateAmount("0"));
		assertEquals(false, bs.validateAmount("-12345"));
	}
	

}
